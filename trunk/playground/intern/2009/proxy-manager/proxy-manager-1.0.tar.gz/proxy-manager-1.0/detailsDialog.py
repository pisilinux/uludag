# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'detailsDialog.ui'
#
# Created: Paz Eki 14 15:05:57 2007
#      by: The PyQt User Interface Compiler (pyuic) 3-snapshot-20070613
#
# WARNING! All changes made in this file will be lost!


from qt import *
from kdecore import *
from kdeui import *



class detailsDialog(QDialog):
    def __init__(self,parent = None,name = None,modal = 0,fl = 0):
        QDialog.__init__(self,parent,name,modal,fl)

        if not name:
            self.setName("detailsDialog")


        detailsDialogLayout = QGridLayout(self,1,1,11,6,"detailsDialogLayout")
        detailsDialogLayout.setResizeMode(QLayout.Minimum)

        self.ok = QPushButton(self,"ok")

        detailsDialogLayout.addWidget(self.ok,3,1)

        self.cancel = QPushButton(self,"cancel")

        detailsDialogLayout.addWidget(self.cancel,3,2)

        self.textLabel1 = QLabel(self,"textLabel1")

        detailsDialogLayout.addWidget(self.textLabel1,0,0)

        self.user = QLineEdit(self,"user")

        detailsDialogLayout.addMultiCellWidget(self.user,0,0,1,2)

        self.textLabel2 = QLabel(self,"textLabel2")

        detailsDialogLayout.addWidget(self.textLabel2,1,0)

        self.passwd = QLineEdit(self,"passwd")

        detailsDialogLayout.addMultiCellWidget(self.passwd,1,1,1,2)

        self.textLabel1_2 = QLabel(self,"textLabel1_2")
        self.textLabel1_2.setTextFormat(QLabel.RichText)
        self.textLabel1_2.setAlignment(QLabel.WordBreak | QLabel.AlignCenter)

        detailsDialogLayout.addMultiCellWidget(self.textLabel1_2,2,2,0,2)

        self.languageChange()

        self.resize(QSize(354,177).expandedTo(self.minimumSizeHint()))
        self.clearWState(Qt.WState_Polished)


    def languageChange(self):
        self.setCaption(i18n("Details"))
        self.ok.setText(i18n("OK"))
        self.cancel.setText(i18n("Cancel"))
        self.textLabel1.setText(i18n("User"))
        self.textLabel2.setText(i18n("Password"))
        self.textLabel1_2.setText(i18n("<font color=\"#ff0000\">Warning: </font>Your username and password will be stored in plain text in your \"home\", without any encyription!"))

