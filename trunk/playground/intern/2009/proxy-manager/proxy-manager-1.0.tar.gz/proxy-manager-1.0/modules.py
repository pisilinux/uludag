[firefox]
path = .mozilla/firefox/
module = mozilla
class = Mozilla
